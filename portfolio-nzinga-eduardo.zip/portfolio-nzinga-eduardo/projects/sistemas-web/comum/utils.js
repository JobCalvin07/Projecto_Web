/*	==========	CONFIGURAÇÃO	DA	MOEDA	==========	*/
//	Altere	para	a	sua	realidade:
//			Angola:				{	locale:	'pt-AO',	codigo:	'AOA'	}
//			Moçambique:{	locale:	'pt-MZ',	codigo:	'MZN'	}
//			Portugal:		{	locale:	'pt-PT',	codigo:	'EUR'	}
//			Brasil:				{	locale:	'pt-BR',	codigo:	'BRL'	}
const	MOEDA	=	{	locale:	'pt-AO',	codigo:	'AOA'	};
/*	==========	ATALHOS	DO	DOM	==========	*/
const	$		=	(seletor,	raiz	=	document)	=>	raiz.querySelector(seletor);
const	$$	=	(seletor,	raiz	=	document)	=>	[...raiz.querySelectorAll(seletor)];
/*	==========	FORMATAÇÃO	==========	*/
const	dinheiro	=	n	=>
new	Intl.NumberFormat(MOEDA.locale,	{	style:	'currency',	currency:	MOEDA.codigo	}).format(n	||	0);
//	Converte	texto	digitado	("1500,50")	em	número	(1500.5)
const	num	=	v	=>	parseFloat(String(v).replace(',',	'.'))	||	0;
//	Data	de	hoje	no	formato	AAAA-MM-DD,	no	fuso	horário	LOCAL
const	hoje	=	()	=>
new	Date(Date.now()	-	new	Date().getTimezoneOffset()	*	60000).toISOString().slice(0,	10);
//	Converte	"2026-09-28"	em	"28/09/2026"
const	dataBR	=	iso	=>	new	Date(iso	+	'T00:00:00').toLocaleDateString('pt-PT');
/*	==========	IDENTIFICADOR	ÚNICO	==========	*/
const	uid	=	()	=>	Date.now().toString(36)	+	Math.random().toString(36).slice(2,	6);
/*	==========	SEGURANÇA:	escapar	texto	do	utilizador	==========	*/
const	esc	=	texto	=>
String(texto).replace(/[&<>"']/g,	c	=>
({	'&':	'&amp;',	'<':	'&lt;',	'>':	'&gt;',	'"':	'&quot;',	"'":	'&#39;'	}[c]));
/*	==========	ARMAZENAMENTO	LOCAL	==========	*/
const	Store	=	{
get(chave,	padrao)	{
try	{
const	bruto	=	localStorage.getItem(chave);
return	bruto	===	null	?	padrao	:	JSON.parse(bruto);
}	catch	{	return	padrao;	}										
//	dados	corrompidos	ou	storage	bloqueado
},
set(chave,	valor)	{
try	{	localStorage.setItem(chave,	JSON.stringify(valor));	}
catch	{	aviso('Não	foi	possível	guardar	os	dados.');	}
}
};
/*	==========	FEEDBACK	(toast)	==========	*/
function	aviso(mensagem)	{
let	t	=	$('.toast');
if	(!t)	{
t	=	document.createElement('div');
t.className	=	'toast';
t.setAttribute('role',	'status');			//	leitores	de	ecrã	anunciam	a	mensagem
document.body.append(t);
}
t.textContent	=	mensagem;
t.classList.add('mostrar');
clearTimeout(t._id);
t._id	=	setTimeout(()	=>	t.classList.remove('mostrar'),	2200);
}
//	Descarrega	um	ficheiro	.json	com	todas	as	chaves	que	começam	por	um	dos	prefixos
function	exportarDados(prefixos,	nomeBase)	{
const	dados	=	{};
Object.keys(localStorage)
.filter(chave	=>	prefixos.some(p	=>	chave.startsWith(p)))
.forEach(chave	=>	{	dados[chave]	=	localStorage.getItem(chave);	});
const	conteudo	=	JSON.stringify(
{	versao:	1,	exportadoEm:	new	Date().toISOString(),	dados	},
null,	2																																			
//	null,	2	=	JSON	indentado,	legível
);
//	Blob	=	"ficheiro"	criado	em	memória;	createObjectURL	dá-lhe	um	endereço	temporário
const	blob	=	new	Blob([conteudo],	{	type:	'application/json'	});
const	url	=	URL.createObjectURL(blob);
const	link	=	document.createElement('a');
link.href	=	url;
link.download	=	`${nomeBase}-${hoje()}.json`;			//	o	atributo	download	força	o	descarregamento
link.click();
URL.revokeObjectURL(url);																								
aviso('Cópia	exportada');
}
//	Lê	um	ficheiro	escolhido	pelo	utilizador	e	restaura	os	dados
function	importarDados(ficheiro,	prefixos)	{
const	leitor	=	new	FileReader();
//	liberta	a	memória
leitor.onload	=	()	=>	{
try	{
const	obj	=	JSON.parse(leitor.result);
if	(!obj	||	typeof	obj.dados	!==	'object')	throw	new	Error('formato');
//	1.º	VALIDAR	tudo	(só	chaves	permitidas	e	valores	que	são	JSON	válido)
const	chaves	=	Object.keys(obj.dados)
.filter(chave	=>	prefixos.some(p	=>	chave.startsWith(p)));
if	(!chaves.length)	throw	new	Error('sem	dados	desta	app');
chaves.forEach(chave	=>	JSON.parse(obj.dados[chave]));
//	2.º	GRAVAR	(só	chega	aqui	se	tudo	estava	válido)
chaves.forEach(chave	=>	localStorage.setItem(chave,	obj.dados[chave]));
aviso('Dados	importados!	A	recarregar…');
setTimeout(()	=>	location.reload(),	800);			//	recarregar	refaz	o	ESTADO	a	partir	do	Store
}	catch	{
aviso('Ficheiro	inválido	para	esta	aplicação.');
}
};
leitor.onerror	=	()	=>	aviso('Não	foi	possível	ler	o	ficheiro.');
leitor.readAsText(ficheiro);
}
